import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;

/* * * * * * * * * * * * * * * * * * *
*	                                 *
*		  @author PgmD Dev           *
* 									 *
*	 Criado em 26 de junho de 2022   *
*									 *
* * * * * * * * * * * * * * * * * * */

public class Main
{
	public static void main(String[] args)
	{
		// data padrão -> 2022-06-26
		System.out.println(LocalDate.now().toString()); 
		
		
		// data formatada -> 26/06/2022
		System.out.println(
		DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT)
		.format(LocalDate.now()).toString());
		
		
		// data formatada -> 26 de junho de 2022
		System.out.println(
			DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM)
			.format(LocalDate.now()).toString());
		
		
		// data formatada -> domingo, 26 de junho de 2022
		System.out.println(
			DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL)
			.format(LocalDate.now()).toString());
			
		
		// data formatada -> 26/06/2022 01:35
		System.out.println(
		DateTimeFormatter.ofLocalizedDateTime(FormatStyle.SHORT, FormatStyle.SHORT)
		.format(LocalDateTime.now()).toString());
		
		
		// data formatada -> 26 de jun de 2022 01:38:11
		System.out.println(
			DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM, FormatStyle.MEDIUM)
			.format(ZonedDateTime.now()).toString());
		
		
		// data formatada -> domingo, 26 de junho de 2022 01:36:46 Horário Padrão de Brasília
		System.out.println(
			DateTimeFormatter.ofLocalizedDateTime(FormatStyle.FULL, FormatStyle.FULL)
			.format(ZonedDateTime.now()).toString());
	}
}
